package projectmanegment_bitrice_ci.ap.be.bitriceci;

public class utils {
    public static int addNumbers(int first, int second) {
        return first + second;
    }
}
